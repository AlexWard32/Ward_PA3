import javax.swing.*;
import java.security.SecureRandom;
import java.util.Random;
import java.util.Scanner;


public class multiply {
    public static void main (String args[]) {

        Scanner scnr = new Scanner(System.in);
        SecureRandom random = new SecureRandom();

        int difficultylvl;
        int end = 10;
        float numCorrect = 0;
        System.out.println("Please enter the desired difficulty level 1-4:");
        difficultylvl = scnr.nextInt();
        if(difficultylvl == 1) {
            System.out.println("Difficulty level 1 selected:");
            int randOne = randOne(random);
            int randTwo = randTwo(random);
        }
        else if(difficultylvl == 2) {
            System.out.println("Difficulty level 2 selected:");
            int randOne = randDTwoA (random);
            int randTwo = randTwo(random);
        }
        else if(difficultylvl == 3) {
            System.out.println("Difficulty level 3 selected:");
            int randOne = randOne(random);
            int randTwo = randTwo(random);
        }
        else if (difficultylvl == 4) {
            System.out.println("Difficulty level 4 selected:");
            int randOne = randOne(random);
            int randTwo = randTwo(random);
        }
        else {
            System.out.println("Please select a difficulty level between 1 and 4:");
        }
        for (int i = 0; i < end; i++) {
           //int randOne = randOne(random);
            //int randTwo = randTwo(random);

            int userNum = scnr.nextInt();
            int caseNum;

            caseNum = random.nextInt(4) + 1;
            if (userNum == product(randOne, randTwo)) {
                numCorrect = numCorrect + 1;
                switch (caseNum) {
                    case 1:
                        System.out.println("Very good!");
                        break;
                    case 2:
                        System.out.println("Excellent!");
                        break;
                    case 3:
                        System.out.println("Nice Work!");
                        break;
                    case 4:
                        System.out.println("Keep up the good work!");
                        break;
                }
            } else {
                numCorrect = numCorrect + 0;
                switch (caseNum) {
                    case 1:
                        System.out.println("No. Please try again.");
                        break;
                    case 2:
                        System.out.println("Wrong. Try once more.");
                        break;
                    case 3:
                        System.out.println("Don't give up!");
                        break;
                    case 4:
                        System.out.println("No. Keep trying.");
                        break;


                }
            }
        }


            float Final = numCorrect / 10 * 100;
            System.out.println("Your score is " + Final + "%");
            if ( Final <= 75.0f)
                System.out.println("Please ask your teacher for extra help");
            else
                System.out.println("Conguratulations, you are ready to go to the next level");

    }
        public static int randOne (SecureRandom random){
            int randOne;
            randOne = random.nextInt(10);
            return randOne;
        }

        public static int randTwo (SecureRandom random){
            int randTwo;
            randTwo = random.nextInt(10);
            return randTwo;
        }

        public static int product ( int randOne, int randTwo){
            int product;
            System.out.println("How much is " + randOne + " times " + randTwo + "?");
            product = randOne * randTwo;
            return product;
        }
        public static int divide ( int randOne, int randTwo){
            int divide;
            System.out.println("How much is " + randOne + " divided by  " + randTwo + "?");
            divide = randOne / randTwo;
            return divide;
        }
        public static int subtract ( int randOne, int randTwo){
            int subtract;
            System.out.println("How much is " + randOne + " minus " + randTwo + "?");
            subtract = randOne - randTwo;
            return subtract;
        }
        public static int sum ( int randOne, int randTwo){
            int sum;
            System.out.println("How much is " + randOne + " plus " + randTwo + "?");
            sum = randOne + randTwo;
            return sum;
        }
        public static int randDTwoA (SecureRandom random){
            int randDTwoA;
            randDTwoA = random.nextInt(100);
            return randDTwoA;
        }

        public static int randDTwoB (SecureRandom random){
                int randDTwoB;
                randDTwoB = random.nextInt(100);
                return randDTwoB;
            }
        public static int randDThreeA (SecureRandom random){
            int randDThreeA;
            randDThreeA = random.nextInt(1000);
            return randDThreeA;
        }

        public static int randDThreeB (SecureRandom random){
            int randDThreeB;
            randDThreeB = random.nextInt(1000);
            return randDThreeB;
        }
        public static int randDFourA (SecureRandom random){
            int randDFourA;
            randDFourA = random.nextInt(10000);
            return randDFourA;
        }

        public static int randDFourB (SecureRandom random){
            int randDFourB;
            randDFourB = random.nextInt(10000);
            return randDFourB;
        }


}